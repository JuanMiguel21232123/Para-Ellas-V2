-- Corre esto en Outerbase Studio (una sola vez).
ALTER TABLE products ADD COLUMN stock INTEGER; -- null = sin control de existencias
ALTER TABLE product_variants ADD COLUMN stock INTEGER;
ALTER TABLE order_items ADD COLUMN category TEXT; -- para agrupar Ganancias por categoría
