import { turso } from "../_lib/turso.js";

const CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // sin O/0/I/1, para que no se confundan al leerlo
const genCode = () => Array.from({ length: 6 }, () => CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)]).join("");
const PENDING_LIMIT = 3; // pedidos "pending" simultáneos permitidos por teléfono
const err = (message) => new Response(JSON.stringify({ error: message }), { status: 400, headers: { "Content-Type": "application/json" } });

export async function onRequestPost({ request, env }) {
  const b = await request.json().catch(() => null);
  if (!b) return err("data");

  const name = String(b.name || "").trim(), phone = String(b.phone || "").trim();
  if (name.length < 2 || phone.length < 7) return err("data");

  const instore = !!b.instore;
  const address = String(b.address || "").trim(), hood = String(b.neighborhood || "").trim();
  if (!instore && (address.length < 5 || hood.length < 2)) return err("address");

  const payment = String(b.payment || "");
  if (!instore && !["efectivo", "nequi"].includes(payment)) return err("payment");

  const items = Array.isArray(b.items) ? b.items : [];
  if (!items.length) return err("items");

  // Revalida cada línea contra el catálogo real: nunca se confía en precios que vengan del navegador
  const lines = [];
  for (const it of items) {
    const { rows } = await turso(env, "SELECT id, name, category, price, active FROM products WHERE id = ?", [it.id]);
    const p = rows[0];
    if (!p || !p.active) return err("invalid");
    let variantName = null, price = p.price;
    if (it.variant_id) {
      const { rows: vr } = await turso(env, "SELECT id, name, price, active FROM product_variants WHERE id = ? AND product_id = ?", [it.variant_id, it.id]);
      const v = vr[0];
      if (!v || !v.active) return err("variant");
      variantName = v.name;
      price = v.price != null ? v.price : p.price;
    }
    const qty = Math.max(1, Math.min(20, Number(it.qty) || 1));
    lines.push({ product_id: p.id, variant_id: it.variant_id || null, name: p.name, category: p.category, variant_name: variantName, price, qty });
  }

  const { rows: pending } = await turso(env, "SELECT COUNT(*) AS n FROM orders WHERE customer_phone = ? AND status = 'pending'", [phone]);
  if ((pending[0]?.n || 0) >= PENDING_LIMIT) return err("limit");

  const total = lines.reduce((t, l) => t + l.price * l.qty, 0);
  let code = genCode();
  for (let i = 0; i < 5; i++) {
    const { rows } = await turso(env, "SELECT 1 FROM orders WHERE code = ?", [code]);
    if (!rows.length) break;
    code = genCode();
  }

  const { lastInsertRowid: orderId } = await turso(env,
    `INSERT INTO orders (code, customer_name, customer_phone, delivery_type, address, neighborhood, payment_method, preferred_time, notes, total, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')`,
    [code, name, phone, instore ? "tienda" : "domicilio", instore ? null : address, instore ? null : hood,
      instore ? null : payment, b.time || null, b.notes || null, total]);

  for (const l of lines) {
    await turso(env,
      "INSERT INTO order_items (order_id, product_id, variant_id, name, variant_name, price, quantity, category) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
      [orderId, l.product_id, l.variant_id, l.name, l.variant_name, l.price, l.qty, l.category]);
  }

  return new Response(JSON.stringify({ code, total }), { headers: { "Content-Type": "application/json" } });
}
