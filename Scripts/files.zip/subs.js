import { turso } from "../../_lib/turso.js";

export async function onRequestGet({ request, env }) {
  const cat = new URL(request.url).searchParams.get("c") || "";
  const { rows } = await turso(env,
    "SELECT id, name, sort_order FROM subcategories WHERE category = ? AND active = 1 ORDER BY sort_order, id", [cat]);
  return new Response(JSON.stringify(rows), { headers: { "Content-Type": "application/json" } });
}
