import { turso } from "../../_lib/turso.js";

export async function onRequestGet({ env }) {
  const { rows } = await turso(env, "SELECT key, value FROM site_settings");
  return new Response(JSON.stringify(Object.fromEntries(rows.map((r) => [r.key, r.value]))), {
    headers: { "Content-Type": "application/json" },
  });
}
