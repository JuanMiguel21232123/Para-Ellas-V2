import { turso } from "../../_lib/turso.js";

export async function onRequestGet({ env }) {
  const { rows: products } = await turso(env,
    "SELECT id, category, subcategory_id, name, description, price, image_url, stock FROM products WHERE active = 1 ORDER BY created_at DESC");
  const { rows: variants } = await turso(env,
    "SELECT id, product_id, name, price, stock FROM product_variants WHERE active = 1 ORDER BY id");
  const byProduct = {};
  variants.forEach((v) => (byProduct[v.product_id] ||= []).push({
    id: v.id, name: v.name, price: v.price, active: true, sold_out: v.stock != null && v.stock <= 0,
  }));
  const out = products.map((p) => ({
    id: p.id, category: p.category, subcategory_id: p.subcategory_id, name: p.name, description: p.description,
    price: p.price, image_url: p.image_url, sold_out: p.stock != null && p.stock <= 0,
    product_variants: byProduct[p.id] || [],
  }));
  return new Response(JSON.stringify(out), { headers: { "Content-Type": "application/json" } });
}
